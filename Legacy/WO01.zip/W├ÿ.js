function playNote(freq, type){
  osc.push(context.createOscillator());
  var i = osc.length - 1;
  osc[i].type = type;
  osc[i].frequency.value = freq;
  osc[i].connect(context.destination);
  osc[i].start();
}

function playButtonHandler(){
  var freq = document.getElementById('freq').value;
  for (var i = 0; i < 3; i++){
    var num = i + 1; // Use same numbering system as HTML
    var checked = document.getElementById('osc' + num).checked; // Get osc on or off

    if (checked){
      var play = document.getElementById('freq' + num).value; // Get value of freq offset
      var type = document.getElementById('type' + num).value; // Get value of waveform
      var uni = document.getElementById('uni' + num).checked; // Get value of unison
      play = parseFloat(play) + parseFloat(freq); // Add freq offset to initial freq

      if (uni){
        playNote(play - uni, type); // Start lower unison oscillator
        playNote(uni + play, type); // Start higher unison oscillator
      }

      playNote(play, type); // Start main oscillator
    }
  }
}

function stopButtonHandler(){
    for (var i = 0; i in osc; i++){
      osc[i].stop();
    }
    osc = [];
}


var osc = []; // Oscillator array

var context = new(window.AudioContext)(); // Create audio context
