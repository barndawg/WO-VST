function playNote(freq, type){
  osc.push(context.createOscillator()); // Create oscilllator
  var i = osc.length - 1; // Get oscillator's item number in array

  osc[i].type = type; // Set oscillator's waveform
  osc[i].frequency.value = freq; // Set oscillator's frequency
  osc[i].connect(context.destination); // Connect oscillator to audio destination

  osc[i].connect(gain); // Connect oscillator to gain node

  osc[i].start(); // Start oscillator
}

function playButtonHandler(){
  for (var i = 0; i < 3; i++){
    var num = i + 1; // Use same numbering system as HTML
    var checked = document.getElementById('osc' + num).checked; // Get osc on or off

    if (checked){
      var freq = document.getElementById('freq').value; // Get initial frequency
      var play = document.getElementById('freq' + num).value; // Get value of freq offset
      var type = document.getElementById('type' + num).value; // Get value of waveform
      var uni = document.getElementById('uni' + num).checked; // Get value of unison
      var offset = document.getElementById('ofs' + num).value; // Get value of unison offset
      play = parseFloat(play) + parseFloat(freq); // Add freq offset to initial freq

      if (uni){
        playNote(play - offset, type); // Start lower unison oscillator
        playNote(parseFloat(play) + parseFloat(offset), type); // Start higher unison oscillator
      }

      playNote(play, type); // Start main oscillator
    }
  }
}

function stopButtonHandler(){
    for (var i = 0; i in osc; i++){
      osc[i].stop(); // Stop all oscillators in array
    }
    osc = []; // Delete all oscillators in array
}


var osc = []; // Create oscillator array

var context = new AudioContext(); // Create audio context
var gain = context.createGain(); // Create gain node for volume control
gain.connect(context.destination); // Connect gain node to audio destination
gain.gain.value = 0.2; // Set overall volume
