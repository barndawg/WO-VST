Hey there, person. It's Barney (WATSØN) here. Here is a really
basic, pre-alpha version of WØ-VST, a virtual instrument I'm working on using
the new JavaScript AudioContext API thingy. It's currently really basic, but
it works. You can mess around with the frequencies and settings for a bit, but
I warn you - TURN YOUR VOLUME DOWN! The volume is still very unpredictable and
I'm not sure at the moment how to fix this. The two checkboxes next to the
oscillator waveforms are to activate the oscillator (L) and to activate a
2-voice unison of that oscillator (R).

Update v0.2: I've fixed an issue with the unison offsets not being taken into
account, and the volume should be marginally better.

Update v0.3: Actual UI! JAJ! Some fixes to unison as well.
